<?php return array (
  'blog' => 'App\\Http\\Livewire\\Blog',
);