<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>My Blog</h1>
    <div class="py-4">
        <div class="list-group">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-between">
                <a href="<?php echo e(url('/blog?id='.$blog->id)); ?>" class="nav-link text-primary"><h4><?php echo e($blog->title); ?></h4></a>
                <div class="d-flex gap-3">
                    <?php if($blog->userid == Auth::user()->id): ?>
                    <a href="<?php echo e(url('/edit_blog?id=')); ?><?php echo e($blog->id); ?>" class="btn btn-success">Edit</a>
                    <button class="btn btn-danger" onclick="del(`<?php echo e($blog->id); ?>`,`<?php echo e($blog->title); ?>`)">Delete</button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="d-flex">
                <small><?php echo e($blog->name); ?></small>
                <small><?php echo e($blog->publish_date); ?></small>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="py-4">
        <?php echo $blogs->links('pagination::bootstrap-4'); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    function del(id,title)
    {
        Swal.fire({
        title: `Do you want delete \n"${title}"?`,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        }).then((result) => {
            if (result.isConfirmed) {
                var data = {
                    id: id
                };
                var xhr = new XMLHttpRequest();
                xhr.open("GET", `/delete_blog?id=${id}`, true);
                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == XMLHttpRequest.DONE) {
                        console.log(xhr.responseText);
                    }
                };
                xhr.send(JSON.stringify(data));
                
                Swal.fire('Deleted!', '', 'success');
                window.location.href = '/home';
            } 
        })
    }
</script>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/blog/resources/views/home.blade.php ENDPATH**/ ?>