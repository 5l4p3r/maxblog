<div class="container">
    <div class="d-flex justify-content-between">
        <h3>Blog List</h3>
        <div>
            <input name="search" id="search" class="form-control" placeholder="Search..." wire:model="search" type="search">
        </div>
    </div>
    <hr>
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-group-item">
            <div class="d-flex justify-content-between">
                <a href="<?php echo e(url('/blog?id='.$blog->id)); ?>" class="nav-link text-primary"><h4><?php echo e($blog->title); ?></h4></a>
                <div class="d-flex gap-3">
                    <?php if(Auth::user()): ?>
                        <?php if($blog->userid == Auth::user()->id): ?>
                        <a href="<?php echo e(url('/edit_blog?id=')); ?><?php echo e($blog->id); ?>" class="btn btn-success">Edit</a>
                        <button class="btn btn-danger" onclick="del(`<?php echo e($blog->id); ?>`,`<?php echo e($blog->title); ?>`)">Delete</button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="d-flex">
                <small><b><?php echo e($blog->name); ?></b>, &nbsp;</small>
                <small><?php echo e($blog->publish_date); ?></small>
            </div>
        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="py-4">
        <?php echo $blogs->links('pagination::bootstrap-4'); ?>

    </div>
</div>
<script>
    function del(id,title)
    {
        Swal.fire({
        title: `Do you want delete \n"${title}"?`,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        }).then((result) => {
            if (result.isConfirmed) {
                var data = {
                    id: id
                };
                var xhr = new XMLHttpRequest();
                xhr.open("GET", `/delete_blog?id=${id}`, true);
                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == XMLHttpRequest.DONE) {
                        console.log(xhr.responseText);
                    }
                };
                xhr.send(JSON.stringify(data));
                
                Swal.fire('Deleted!', '', 'success');
                window.location.href = '/';
            } 
        })
    }
</script>
<?php /**PATH /var/www/blog/resources/views/livewire/blog.blade.php ENDPATH**/ ?>