<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create Blog</h1>
    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(url('edit_blog')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
            <label for="title">Title</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e($item->title); ?>">

            <div class="mb-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" name="content"
                    id="tinymce"><?php echo html_entity_decode($item->content); ?></textarea>

                <?php if($errors->has('content')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('content')); ?></span>
                <?php endif; ?>
            </div>
            <div class="d-flex gap-3">
                <label for="status">Status</label>
                <select name="status" id="status" class="nav-link dropdown-toggle">
                    <option value="<?php echo e($item->status); ?>"><?php echo e($item->status); ?></option>
                    <option value="draft">Draft</option>
                    <option value="publish">Publish</option>
                </select>
            </div>
            <div class="mb-3 py-4">
                <input type="submit" value="Save" class="btn btn-primary">
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/blog/resources/views/edit_blog.blade.php ENDPATH**/ ?>