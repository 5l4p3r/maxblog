<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog')->html();
} elseif ($_instance->childHasBeenRendered('SInyM0H')) {
    $componentId = $_instance->getRenderedChildComponentId('SInyM0H');
    $componentTag = $_instance->getRenderedChildComponentTagName('SInyM0H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SInyM0H');
} else {
    $response = \Livewire\Livewire::mount('blog');
    $html = $response->html();
    $_instance->logRenderedChild('SInyM0H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/blog/resources/views/welcome.blade.php ENDPATH**/ ?>