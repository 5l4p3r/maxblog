<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $blogsss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><?php echo e($blog->title); ?></h1><br>
        <p>Author: <?php echo e($blog->name); ?>, <?php echo e($blog->publish_date); ?></p>
        <div class="py-4"><?php echo html_entity_decode($blog->content); ?></div>
        <input type="hidden" name="blogid" id="blogid" value="<?php echo e($blog->id); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="py-4">
        <h3>Comments:</h3>
        <?php 
            for($i = 0; $i < sizeof($comments); $i++)
            {
                ?>
                    <div id="comment" class="d-flex justify-content-between py-2">
                        <div><b><?php echo e($comments[$i]['name']); ?></b> : "<?php echo e($comments[$i]['comment']); ?>", &nbsp; &nbsp;  <?php echo e($comments[$i]['date']); ?></div>
                        <?php if(Auth::user()): ?>
                            <?php if(Auth::user()->id == $comments[$i]['userid']): ?>
                                <button class="btn btn-danger" onclick="del(`<?php echo e($comments[$i]['id']); ?>`,`<?php echo e($comments[$i]['comment']); ?>`)">
                                    <img src="<?php echo e(asset('img/trash.png')); ?>" alt="del" class="minicon">
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php
            }
        ?>
        <?php $__currentLoopData = $blogsss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::user()): ?>
                <div class="py-3">
                    <form action="<?php echo e(url('add_comment')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="input-group gap-3">
                            <input type="hidden" name="blogid" value="<?php echo e($item->id); ?>">
                            <input type="text" name="commentar" id="commentar" class="form-control" placeholder="Add comment">
                            <input type="submit" value="Add Comment" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <div class="py-3">
                    <div class="input-group gap-3">
                        <input type="text" class="form-control" placeholder="Add comment">
                        <a href="/home" class="btn btn-primary">Add Comment</a>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<script>
    function del(id,title)
    {
        Swal.fire({
        title: `Do you want delete \n"${title}"?`,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        }).then((result) => {
            if (result.isConfirmed) {
                var data = {
                    id: id
                };
                var xhr = new XMLHttpRequest();
                xhr.open("GET", `/delete_comment?id=${id}`, true);
                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == XMLHttpRequest.DONE) {
                        console.log(xhr.responseText);
                    }
                };
                xhr.send(JSON.stringify(data));
                
                Swal.fire('Deleted!', '', 'success');
                window.location.href = `/blog?id=${document.getElementById('blogid').value}`;
            } 
        })
    }
</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/blog/resources/views/blog_detail.blade.php ENDPATH**/ ?>